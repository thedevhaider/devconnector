module.exports = {
  mongoURI:
    "mongodb://thedevhaider:iamawesome1503436@ds129600.mlab.com:29600/devzone",
  secretOrKey: "secret"
};
