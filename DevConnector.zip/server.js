const express = require("express");
const mongoose = require("mongoose");
const users = require("./routes/api/users");
const posts = require("./routes/api/posts");
const profile = require("./routes/api/profile");
const passport = require("passport");
const bodyParser = require("body-parser");

const app = express();

//Adding middlerware to express app
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

//Config Keys
const db = require("./config/keys").mongoURI;

//Connect to MongoDB using Mongoose
mongoose
  .connect(db)
  .then(() => console.log("MongoDB connected"))
  .catch(err => console.log(err));

//Adding passport middleware
app.use(passport.initialize());

//Passport Config
require("./config/passport")(passport);

app.get("/", (req, res) => res.send("Hello fraands. Chai pelo"));
app.use("/api/users", users);
app.use("/api/profile", profile);
app.use("/api/posts", posts);

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => console.log(`Running server on Port ${PORT}`));
